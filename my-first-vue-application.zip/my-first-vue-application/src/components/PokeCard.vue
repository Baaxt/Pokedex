<template>
    <div class="card" :class="[type, { 'flipped': isFlipped }]" @click="flipCard">
        <div class="card-face front">
            <img :src="`assets/images/${pokemon.image}`" :alt="pokemon.name" class="pokemon-image">
            <p>{{pokemon.name}}</p>
        </div>
        <div class="card-face back">
            <div class="stats-container">
                <div class="stat">
                    <span class="stat-name">Name :</span>
                    <span class="stat-value">{{pokemon.name}}</span>
                </div>
                <div class="stat">
                    <span class="stat-name">PV :</span>
                    <span class="stat-value">{{pokemon.hp}}</span>
                </div>
                <div class="stat">
                    <span class="stat-name">Attaque :</span>
                    <span class="stat-value">{{pokemon.attack}}</span>
                </div>
                <div class="stat">
                    <span class="stat-name">Défense :</span>
                    <span class="stat-value">{{pokemon.defense}}</span>
                </div>
                <div class="stat">
                    <span class="stat-name">Type :</span>
                    <span class="stat-value">{{pokemon.type1}}</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        pokemon: {
            type: Object,
            required: true
        }
    },
    computed: {
        type(){
            return this.pokemon.type1.toLowerCase()
        }
    },
    data() {
        return {
            isFlipped: false
        };
    },
    methods: {
        flipCard() {
            this.isFlipped = !this.isFlipped;
        }
    }
}
</script>

<style scoped>
.card {
    margin: 1em;
    padding: 1em;
    width: 18vw;
    height: 300px; /* Ajustez la hauteur en fonction du contenu des statistiques */
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border-radius: 15px;
    background-color: rgb(255, 140, 188);
    perspective: 1000px; /* Permet la perspective 3D */
    position: relative; /* Position relative pour le positionnement des faces */
}

.card-face {
    position: absolute;
    width: 100%;
    height: 100%;
    backface-visibility: hidden; /* Cache le dos de la carte */
    transition: transform 0.5s ease; /* Ajoute une transition fluide à la rotation */
}

.front {
    z-index: 2; /* Face avant au-dessus de la face arrière */
}

.back {
    transform: rotateY(180deg); /* Rotation initiale de la face arrière */
    z-index: 1; /* Face arrière en dessous de la face avant */
}

.card.flipped .front {
    transform: rotateY(180deg); /* Rotation de la face avant lorsqu'elle est retournée */
}

.card.flipped .back {
    transform: rotateY(0deg); /* Rotation de la face arrière lorsqu'elle est retournée */
}

.pokemon-image {
    width: 250px;
    height: 250px;
    margin-bottom: 0.5em;
}

.stats-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
}

.stat {
    display: flex;
    align-items: center;
    margin-bottom: 0.5em;
}

.stat-name {
    font-weight: bold;
    margin-right: 0.5em;
}

.stat-value {
    font-style: italic;
}



.feu {
    background: rgb(255,138,138);
    background: linear-gradient(180deg, rgba(255,138,138,1) 0%, rgb(252, 34, 34) 50%, rgba(255,138,138,1) 100%);
}

.eau {
    background: rgb(192,246,250);
    background: linear-gradient(180deg, rgba(192,246,250,1) 0%, rgba(3,164,232,1) 60%);
}


.fée {
    background: rgb(246,180,209);
    background: linear-gradient(180deg, rgba(246,180,209,1) 0%, rgba(255,224,238,1) 50%, rgba(252,94,164,1) 100%);
}

.herbe {
    background: rgb(158,254,208);
    background: linear-gradient(180deg, rgba(158,254,208,1) 0%, rgba(3,142,0,1) 46%, rgb(0, 185, 96) 100%);       
}

.electrique {
    background: rgb(255,244,149);
    background: linear-gradient(180deg, rgba(255,244,149,1) 0%, rgba(255,208,42,1) 50%, rgba(201,181,0,1) 100%);
}

.tenebre {
    background: rgb(209,135,255);
    background: linear-gradient(180deg, rgb(105, 0, 170) 0%, rgba(86, 0, 140, 0.826), rgb(139, 0, 226) 100%);
}

.psy {
    background: rgb(255, 96, 165);
    background: linear-gradient(180deg, rgb(255, 106, 170) 0%, rgb(254, 14, 122)50%, rgba(252,94,164,1) 100%);  
}

.sol {
    background: rgb(255,209,139);
    background: linear-gradient(180deg, rgba(255,209,139,1) 0%, rgba(255,140,6,1) 50%, rgba(255,203,146,1) 100%);
}

.dragon {
    background-color: #8A2BE2; /* Couleur pour le type Dragon */
}

.poison {
    background: rgb(171,37,255);
    background: linear-gradient(259deg, rgba(171,37,255,1) 0%, rgba(202,116,255,1) 50%, rgba(171,37,255,1) 100%);
}

.normal {
    background: rgb(255,246,236);
    background: linear-gradient(180deg, rgba(255,246,236,1) 0%, rgba(255,219,179,1) 50%, rgb(255, 193, 126) 100%);
}
</style>


