<template>
    <div class="container">

    
    <PokeCard v-for="pokemon of pokemons" :key="pokemon" v-bind:pokemon="pokemon">
    </PokeCard>
</div>
</template>
<script>
import PokeCard from './PokeCard.vue';
import Data from '../Data/pokemon.json';
export default {
  name: 'PokeList',
  components: {
    PokeCard
  },
  data() {
    return {
        pokemons: Data,
    }
  },
  created(){

  }

}
</script>

<style scoped>
.container{
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}
</style>