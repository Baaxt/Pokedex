<template>
  <div>
    <header>
      <img src="./assets/logo.png" alt="">
    </header>
    <main>
      <PokeList />
    </main>
    <footer>
      <img src="./assets/footer.png" alt="">
    </footer>
  </div>
</template>

<script>
import PokeList from './components/PokeList.vue'

export default {
  name: 'App',
  components: {
    PokeList
  }
}
</script>

<style>
body {
  padding-top: 2cap;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #ffffff;
  margin-top: 60px;
  height: 215vh;
  background: linear-gradient(to bottom, #b58bff, #6e0b8a);

}
</style>

<style>
footer {
  padding-top: 60px;

}
</style>

<style>
header {
  padding-bottom: 120px;

}
</style>
